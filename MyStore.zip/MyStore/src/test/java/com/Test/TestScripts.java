package com.Test;

import org.testng.annotations.Test;

import com.Base.BaseTest;
import com.MyStorePages.Blouses;
import com.MyStorePages.CasualDresses;
import com.MyStorePages.EveningDresses;
import com.MyStorePages.HomePage;
import com.MyStorePages.SummerDresses;
import com.MyStorePages.TShirtPage;

public class TestScripts extends BaseTest {


		@Test
		public void aHome() throws Exception
		{
		HomePage h = new HomePage(driver);
		HomePage.women();
		h.clickTshirt();
		}

		@Test
		public void bTshirt() throws Exception
		{
		TShirtPage t = new TShirtPage(driver);
		t.tShirtpage();
		}
		@Test
		public void cBlouse() throws Exception
		{
		Blouses b = new Blouses(driver);
		b.blousesPage();
		}
		
		@Test
		public void dCasual() throws Exception
		{
		CasualDresses c = new CasualDresses(driver);
		c.casualDressPage();
		}
		
		@Test
		public void eEvening() throws Exception
		{
		EveningDresses e = new EveningDresses(driver);
		e.eveningDressPage();
		}

		@Test
		public void fSummer() throws Exception
		{
		SummerDresses s = new SummerDresses(driver);
		s.summerDressesPage();
		}

}
