package com.Utility;

import java.io.File;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Screenshot {

	public static void screenshot(WebDriver driver) throws Exception {
		TakesScreenshot t = (TakesScreenshot) driver;
		File source = t.getScreenshotAs(OutputType.FILE);
		String title = driver.getTitle();
		File destination = new File("./Screenshot/" + title +".png");
		FileUtils.copyFile(source, destination);
	}
}
