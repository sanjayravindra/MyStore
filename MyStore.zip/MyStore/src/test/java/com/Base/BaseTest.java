package com.Base;


import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class BaseTest {

	
	
	public static WebDriver driver;
	public static Logger log = Logger.getLogger("Test");
	static
	{
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\sanjay.ravindra\\eclipse-workspace\\MyStore\\Driver\\chromedriver.exe");
	}
	
	@BeforeTest
	public void beforeTest()
	{
		
driver = new ChromeDriver();
driver.manage().window().maximize();
log.info("Browser opened");
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
driver.get("http://automationpractice.com/index.php");
	}

	
	@AfterTest
	public void afterTest()
	{
		driver.close();
	}
}
