package com.MyStorePages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.Base.BaseTest;
import com.Utility.Screenshot;

public class TShirtPage extends BaseTest
{
	@FindBy (className = "cat-name")
	public WebElement category;
	
	@FindBy (xpath = "(//img[@class='replace-2x img-responsive'])[2]")
	public WebElement product;
	
	@FindBy (xpath = "//span[contains(text(), 'Add to cart')]")
	public WebElement cart;
	
	@FindBy (className = "cross")
	public WebElement close;
	
	public TShirtPage(WebDriver driver) {
	super();
	PageFactory.initElements(driver, this);
}
	
	public void tShirtpage() throws Exception
	{
		try
		{
	String cat = category.getText();
	Assert.assertEquals(cat, "T-SHIRTS ");
	log.info("T-Shirt page is validated");
	WebElement add = product;
	HomePage.getAction().moveToElement(add).build().perform();
	cart.click();
	validate();
	log.info("Product successfully added to cart");
//	Screenshot.screenshot(driver);
	close.click();
		}
		catch(Exception e)
		{
			log.fatal("Failed to add T-Shirt product to cart");
			Screenshot.screenshot(driver);
		}
	}
	public static void validate()
	{
		String message = ((JavascriptExecutor)driver).executeScript("return arguments[0].lastChild.textContent;", new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'layer_cart_product')]//h2")))).toString();
		String validate = message.substring(0, 48);
			assertEquals(validate, "Product successfully added to your shopping cart");
	}
}
