package com.MyStorePages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.Base.BaseTest;
import com.Utility.Screenshot;

public class HomePage extends BaseTest{

@FindBy (xpath = "//a[contains(text(), 'Women')]")
public static WebElement women;

@FindBy (xpath = "//a[contains(text(), 'T-shirts')]")
public WebElement tShirt;

@FindBy (id = "search_query_top")
public WebElement search;	

@FindBy (className = "submit_search")
public WebElement searchButton;

@FindBy (className = "heading-counter")
public WebElement found;
	
	public HomePage(WebDriver driver) {
	super();
	PageFactory.initElements(driver, this);
}

	public static Actions getAction()
	{
		Actions a = new Actions(driver);
		return a;
	}
	public static void women() throws Exception {
		try
		{
		WebElement w = women;	
		HomePage.getAction().moveToElement(w).build().perform();
		}
		catch(Exception e)
		{
			log.fatal("Failed to navigate home page");
			Screenshot.screenshot(driver);
		}
	}

	public void clickTshirt() throws Exception {
		try
		{
			log.info("Navigate to home page");
		tShirt.click();
		log.info("Clicked on T-Shirt link");
		log.info("Navigate to T-Shirt page");
		}
		catch(Exception e)
		{
			log.fatal("Failed to click on T-Shirt link");
			Screenshot.screenshot(driver);
		}
	}

//	public void search()
//	{
//	search.sendKeys("jeans");
//	searchButton.click();
//	String notFound = found.getText();
//	assertFalse(false, "0 results have been found.");
//	}
}
