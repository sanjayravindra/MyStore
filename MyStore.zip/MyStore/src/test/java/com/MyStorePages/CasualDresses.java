package com.MyStorePages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.Base.BaseTest;
import com.Utility.Screenshot;

public class CasualDresses extends BaseTest
{
	@FindBy (className = "category-name")
	public WebElement category;
	
	@FindBy (xpath = "//a[contains(text(),'Casual Dresses')]" )
	public WebElement casual;
	
	@FindBy (xpath = "(//img[@class='replace-2x img-responsive'])[2]")
	public WebElement product;
	
	@FindBy (xpath = "//span[contains(text(), 'Add to cart')]")
	public WebElement cart;
	
	@FindBy (className = "cross")
	public WebElement close;
	
	
	public CasualDresses(WebDriver driver) {
	super();
	PageFactory.initElements(driver, this);
}

	public void casualDressPage() throws Exception
	{
		try
		{
			try
			{
		HomePage.women();
		casual.click();
		log.info("Navigate to Casual Dresses page");
		String cat = category.getText();
		Assert.assertEquals(cat, "Casual Dresses");
		log.info("Casual Dresses page is validated");
			}
			catch(Exception e)
			{
				Screenshot.screenshot(driver);
				log.fatal("Failed to navigate Casual Dresses page");
			}
		WebElement add = product;
		HomePage.getAction().moveToElement(add).build().perform();
		cart.click();
//		TShirtPage.validate();
		assertEquals("a", "b");
		log.info("Product successfully added to cart");
		//Screenshot.screenshot(driver);
		close.click();
		}
		catch(AssertionError e)
		{
			log.fatal("Failed to add Casual Dresses product to cart");
			Screenshot.screenshot(driver);
			System.out.println(e.getStackTrace());
		}
	}
	
}
