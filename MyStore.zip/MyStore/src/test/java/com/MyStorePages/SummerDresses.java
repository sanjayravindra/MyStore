package com.MyStorePages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.Base.BaseTest;
import com.Utility.Screenshot;

public class SummerDresses extends BaseTest
{

	@FindBy (className = "category-name")
	public WebElement category;
	
	@FindBy (xpath = "//a[contains(text(),'Summer Dresses')]" )
	public WebElement summer;
	
	@FindBy (xpath = "(//img[@class='replace-2x img-responsive'])[2]")
	public WebElement product;
	
	@FindBy (xpath = "//span[contains(text(), 'Add to cart')]")
	public WebElement cart;
	
	@FindBy (className = "cross")
	public WebElement close;
	
	
	public SummerDresses(WebDriver driver) {
	super();
	PageFactory.initElements(driver, this);
}

	public void summerDressesPage() throws Exception
	{
		try
		{
			try
			{
		HomePage.women();
		summer.click();
		log.info("Navigate to Summer Dresses page");
		String cat = category.getText();
		Assert.assertEquals(cat, "Summer Dresses");
		log.info("Summer Dresses page is validated");
			}
			catch(Exception e)
			{
				Screenshot.screenshot(driver);
				log.fatal("Failed to navigate Summer Dresses page");
			}
		WebElement add = product;
		HomePage.getAction().moveToElement(add).build().perform();
		cart.click();
		TShirtPage.validate();
		log.info("Product successfully added to cart");
		//Screenshot.screenshot(driver);
		close.click();
		}
		catch(Exception e)
		{
			log.fatal("Failed to add Summer Dresses product to cart");
			Screenshot.screenshot(driver);
		}
		
	}
}
